from abc import ABC, abstractmethod

# str check
def chk(v):
    ok = True
    if not v or type(v) != str:
      ok = False
    else:
      n = len(v.strip())
      if n == 0:
          ok = False
    return ok


class RentalItem(ABC):
    def __init__(self, item_id, brand, hourly_rate):
        # check id
        ok1 = chk(item_id)
        if ok1 == False:
          e1 = "Item ID must be a non-empty string."
          raise ValueError(e1)

        ok2 = chk(brand)
        if ok2 == False:
          e2 = "Brand must be provided."
          raise ValueError(e2)

        # rate check
        r = float(hourly_rate)
        if r < 0:
          e3 = "Hourly rate cannot be negative."
          raise ValueError(e3)

        i = item_id.strip()
        b = brand.strip()

        self._item_id = i
        self._brand = b
        self._hourly_rate = r
        self._is_rented = False

    @property
    def item_id(self):
        x = self._item_id
        return x

    @property
    def brand(self):
        y = self._brand
        return y

    @property
    def hourly_rate(self):
        z = self._hourly_rate
        return z

    @property
    def is_rented(self):
        q = self._is_rented
        return q

    @abstractmethod
    def calculate_rental_cost(self, hours):
        pass

    @abstractmethod
    def borrow(self):
        pass

    @abstractmethod
    def return_item(self):
        pass

    @classmethod
    def from_csv_string(cls, data):
        m = "Subclasses must implement this."
        raise NotImplementedError(m)

    # print format
    def __str__(self):
        s = "Available"
        if self._is_rented == True:
          s = "Rented"
        o = "%s - %s ($%.2f/hr) - Status: %s" % (self._item_id, self._brand, self._hourly_rate, s)
        return o