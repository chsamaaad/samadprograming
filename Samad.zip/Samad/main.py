from bicycle import Bicycle

# helper to print current floor status
def show_rack(bike_list, shift_title):
    print("\n=== Dorset St Cycles - " + shift_title + " ===")
    
    avail_cnt = 0
    for i in range(len(bike_list)):
        b = bike_list[i]
        print("  " + str(b))
        if b.is_rented == False:
            avail_cnt = avail_cnt + 1

    print("  [Floor Summary: %d/%d frames available in rack]" % (avail_cnt, len(bike_list)))


# handle customer rental logic
def do_rental(b, cust, hrs, reg_data):
    try:
        price = b.calculate_rental_cost(hrs)
        res = b.borrow()
        if res == False:
            raise ValueError(b.item_id + " is already rented out.")

        reg_data["expected_takings"] = reg_data["expected_takings"] + price
        reg_data["dockets_issued"] += 1

        disc_note = ""
        if hrs > 5:
            disc_note = " (includes 10% discount)"

        # print receipt line
        print("  [OK] Dispatched {} to {} for {}h -> EUR {:.2f}{}".format(b.item_id, cust, hrs, price, disc_note))
    except ValueError as err:
        reg_data["rejected_attempts"].append((b.item_id, str(err)))
        print("  [BLOCKED] Could not dispatch " + b.item_id + " to " + cust + ": " + str(err))


def main():
    # setup initial bikes
    b1 = Bicycle("DSC-101", "Trek", 12.00, "Mountain", 18)
    b2 = Bicycle("DSC-102", "Giant", 15.00, "Road", 21)
    b3 = Bicycle.from_csv_string("DSC-103, Specialized, 10.50, Hybrid, 7")
    b4 = Bicycle.from_csv_string("DSC-104, Cube, 20.00, Electric, 8")

    shop_rack = [b1, b2, b3, b4]
    
    # register dict for tracking cash
    till_box = {
        "expected_takings": 0.0,
        "collected_cash": 0.0,
        "dockets_issued": 0,
        "rejected_attempts": []
    }

    show_rack(shop_rack, "09:00 Morning Opening Rack")

    print("\n--- Morning Counter Bookings ---")
    morning_list = [
        (b1, "Liam O'Connor", 3),
        (b4, "Aoife Murphy", 7),
        (b1, "Sean Gallagher", 2), # already out, should fail
        (b2, "Niamh Kelly", 0),    # invalid hrs test
    ]

    for item in morning_list:
        do_rental(item[0], item[1], item[2], till_box)

    show_rack(shop_rack, "12:30 Midday Rack Status")

    print("\n--- Afternoon Workshop & Tariff Adjustments ---")

    # check return guard on b2
    if b2.is_rented == False:
        print("  [Desk Check] DSC-102 is already on the floor, verifying return_item() guard...")
    
    if b2.return_item() == False:
        err_msg = b2.item_id + " is already in stock."
        till_box["rejected_attempts"].append((b2.item_id, err_msg))
        print("  [BLOCKED] Return rejected: " + err_msg)

    # test bad rate update
    try:
        b3.update_rate(-19.50)
    except ValueError as e:
        till_box["rejected_attempts"].append((b3.item_id, str(e)))
        print("  [BLOCKED] Tariff update rejected on %s: %s" % (b3.item_id, str(e)))

    # test bad csv import
    try:
        Bicycle.from_csv_string("DSC-109, Mongoose, 18.00, BMX, 6")
    except ValueError as err:
        till_box["rejected_attempts"].append(("DSC-109", str(err)))
        print("  [BLOCKED] Stock import rejected: " + str(err))

    # liam returns bike 1
    if b1.return_item() == True:
        total_bill = b1.calculate_rental_cost(3)
        till_box["collected_cash"] = till_box["collected_cash"] + total_bill
        print("  [RETURNED] Liam O'Connor checked in {}. Paid: EUR {:.2f}".format(b1.item_id, total_bill))

    # adjust afternoon rates
    b2.update_rate(14.00)
    b3.update_rate(9.50)
    print("  [TARIFFS] Updated %s to EUR %.2f/hr; updated %s to EUR %.2f/hr" % (
        b2.item_id, b2.hourly_rate, b3.item_id, b3.hourly_rate
    ))

    # end of day summary
    show_rack(shop_rack, "17:30 Closing Rack & Till Reconciliation")
    print("  Shift Totals -> Dockets Issued: {} | Cash Settled: EUR {:.2f} | Blocked Actions Logged: {}".format(
        till_box['dockets_issued'], till_box['collected_cash'], len(till_box['rejected_attempts'])
    ))


if __name__ == "__main__":
    main()