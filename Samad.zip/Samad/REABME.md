# CA1 - Bicycle Rental System

Student Project: Bicycle Rental System (Python OOP)  
Module: Modern Programming Principles & Practice 1  

## Overview
This repository contains implementation of Rental Bicycle system using OOP in Python 3.

## Features

RentalItem abstract class made with the abc module.

Bicycle child class that calculates rent, electric bike extra charges, and long-rental discounts.

Protected variables with @property getters.

Input checks for hourly rates, gears, and valid bike types.

12 unit tests using unittest to check normal cases and errors.

## Running the Code
```bash
python main.py