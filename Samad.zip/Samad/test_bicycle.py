import unittest
from rental_item import RentalItem
from bicycle import Bicycle

class TestBicycleRental(unittest.TestCase):
    def setUp(self):
        # test fixtures init
        self.bike = Bicycle("T01", "Raleigh", 10.0, "Mountain", 18)
        self.ebike = Bicycle("T02", "E-Ride", 20.0, "Electric", 7)

    def test_1_borrow_flow(self):
        self.assertFalse(self.bike.is_rented)
        self.assertEqual(self.bike.item_id, "T01")
        
        # try borrowing
        res = self.bike.borrow()
        self.assertTrue(res)
        self.assertTrue(self.bike.is_rented)
        self.assertFalse(self.bike.borrow()) # double borrow

    def test_return_stuff(self):
        self.assertFalse(self.bike.return_item())
        self.bike.borrow()
        
        ok = self.bike.return_item()
        self.assertTrue(ok)
        self.assertFalse(self.bike.is_rented)

    def test_costs_calc(self):
        c1 = self.bike.calculate_rental_cost(2)
        self.assertEqual(c1, 20.0)
        
        c2 = self.ebike.calculate_rental_cost(2)
        self.assertEqual(c2, 46.0)
        
        # discount test
        val = self.bike.calculate_rental_cost(10)
        self.assertEqual(val, 90.0)

    def test_csv_and_errs(self):
        b_item = Bicycle.from_csv_string("T03, Apollo, 12.5, Road, 21")
        self.assertEqual(b_item.item_id, "T03")
        self.assertEqual(b_item.brand, "Apollo")
        
        with self.assertRaises(ValueError):
            Bicycle("T04", "Apollo", 10.0, "Folding", 6)

        with self.assertRaises(ValueError):
            self.bike.calculate_rental_cost(-3)

        with self.assertRaises(TypeError):
            RentalItem("A01", "Generic", 15.0)

if __name__ == "__main__":
    unittest.main()