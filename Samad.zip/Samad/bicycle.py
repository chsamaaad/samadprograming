from rental_item import RentalItem

# allowed bicycle types list
bike_types = ["Mountain", "Road", "Hybrid", "Electric"]

class Bicycle(RentalItem):
    def __init__(self, item_id, brand, hourly_rate, bike_type, gear_count):
        super().__init__(item_id, brand, hourly_rate)

        # clean and check bike type
        t = bike_type.strip().title()
        if t not in bike_types:
            raise ValueError("Invalid type. Allowed types are: " + str(bike_types))

        if type(gear_count) != int or gear_count <= 0:
            raise ValueError("Gear count must be a positive number.")

        self._bike_type = t
        self._gear_count = gear_count

    @property
    def bike_type(self):
        return self._bike_type

    @property
    def gear_count(self):
        return self._gear_count

    def update_rate(self, new_rate):
        if new_rate <= 0:
            raise ValueError("New rate must be positive.")
        self._hourly_rate = float(new_rate)

    # calculate total rental price
    def calculate_rental_cost(self, hours):
        if hours <= 0:
            raise ValueError("Rental duration must be greater than zero.")

        r = self._hourly_rate

        if self._bike_type == "Electric":
            r = r * 1.15

        total = r * hours

        if hours > 5:
            total = total * 0.90

        return round(total, 2)

    def borrow(self):
        if self._is_rented == True:
            return False
        self._is_rented = True
        return True

    def return_item(self):
        if self._is_rented == False:
            return False
        self._is_rented = False
        return True

    @classmethod
    def from_csv_string(cls, data):
        p = data.split(",")
        if len(p) != 5:
            raise ValueError("CSV input needs 5 comma-separated values.")

        i_id = p[0].strip()
        brand = p[1].strip()
        rate = float(p[2].strip())
        b_type = p[3].strip()
        gears = int(p[4].strip())

        return cls(i_id, brand, rate, b_type, gears)

    # format string output
    def __str__(self):
        base_info = super().__str__()
        return "%s | Type: %s, Gears: %d" % (base_info, self._bike_type, self._gear_count)